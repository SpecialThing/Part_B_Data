//
// Created by krab1k on 30.1.19.
//

#include "writer.h"


Writer::~Writer() = default;
